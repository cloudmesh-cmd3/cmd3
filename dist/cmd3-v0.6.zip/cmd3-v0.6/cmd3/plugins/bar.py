from cmd3.shell import command


class bar:

    def activate_bar(self):
        pass

    def do_bar(self, arg):
        """
        Usage:
            bar line

        """
        print "BAR", arg
