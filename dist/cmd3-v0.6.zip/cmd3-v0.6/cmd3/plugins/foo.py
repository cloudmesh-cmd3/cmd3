from cmd3.shell import command


class foo:

    def activate_foo(self):
        pass

    def do_foo(self, arg):
        """
        Usage:
            foo line

        """
        print "FOO", arg
