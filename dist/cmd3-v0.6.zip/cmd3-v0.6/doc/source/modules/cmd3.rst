cmd3 Package
============

:mod:`cmd3` Package
-------------------

.. automodule:: cmd3.__init__
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`shell` Module
-------------------

.. automodule:: cmd3.shell
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    cmd3.cyberaide
    cmd3.plugins

