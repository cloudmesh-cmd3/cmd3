plugins Package
===============

:mod:`activate` Module
----------------------

.. automodule:: cmd3.plugins.activate
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`bar` Module
-----------------

.. automodule:: cmd3.plugins.bar
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`clear` Module
-------------------

.. automodule:: cmd3.plugins.clear
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`edit` Module
------------------

.. automodule:: cmd3.plugins.edit
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`foo` Module
-----------------

.. automodule:: cmd3.plugins.foo
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`graphviz` Module
----------------------

.. automodule:: cmd3.plugins.graphviz
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`info` Module
------------------

.. automodule:: cmd3.plugins.info
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`metric` Module
--------------------

.. automodule:: cmd3.plugins.metric
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`opt_example` Module
-------------------------

.. automodule:: cmd3.plugins.opt_example
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`pause` Module
-------------------

.. automodule:: cmd3.plugins.pause
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`rst` Module
-----------------

.. automodule:: cmd3.plugins.rst
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`shell_core` Module
------------------------

.. automodule:: cmd3.plugins.shell_core
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`template` Module
----------------------

.. automodule:: cmd3.plugins.template
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`timer` Module
-------------------

.. automodule:: cmd3.plugins.timer
    :members:
    :undoc-members:
    :show-inheritance:

