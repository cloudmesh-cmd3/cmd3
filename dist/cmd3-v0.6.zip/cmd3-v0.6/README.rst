cmd3 - A dynamic CMD shell with plugins
=========================================

cmd is an extension for the CMD class with the following features:

* commands are loaded from plugin directories 
* usage of docopts as part of the command creation
* variable substitution
* execution of python commands
* scripts loadable from a script directory

Through these extensions cmd becomes very flicible and can be used to
extend command shell interface through simple add-ons via very simple
plugins provided as classes.

The documentation is located at 

* http://cloudmesh.github.com/cmd3/

